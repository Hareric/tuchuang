return {
  ["workshop-1207269058"]={ configuration_options={  }, enabled=true },
  ["workshop-356930882"]={
    configuration_options={ uses=10000000, uses2=10000000, uses3=10000000 },
    enabled=true 
  },
  ["workshop-458587300"]={ configuration_options={ Ownership=false, Travel_Cost=32 }, enabled=true },
  ["workshop-462434129"]={
    configuration_options={
      MOD_RESTART_ALLOW_KILL=true,
      MOD_RESTART_ALLOW_RESTART=true,
      MOD_RESTART_ALLOW_RESURRECT=true,
      MOD_RESTART_CD_BONUS=0,
      MOD_RESTART_CD_KILL=3,
      MOD_RESTART_CD_MAX=0,
      MOD_RESTART_CD_RESTART=5,
      MOD_RESTART_CD_RESURRECT=7,
      MOD_RESTART_FORCE_DROP_MODE=0,
      MOD_RESTART_IGNORING_ADMIN=true,
      MOD_RESTART_MAP_SAVE=2,
      MOD_RESTART_RESURRECT_HEALTH=0,
      MOD_RESTART_TRIGGER_MODE=1,
      MOD_RESTART_WELCOME_TIPS=true,
      MOD_RESTART_WELCOME_TIPS_TIME=6 
    },
    enabled=true 
  },
  ["workshop-466732225"]={ configuration_options={  }, enabled=true },
  ["workshop-661253977"]={
    configuration_options={ amudiao=true, baodiao=1, kong=0, nillots=0, rendiao=2, zbdiao=true },
    enabled=true 
  },
  ["workshop-666155465"]={
    configuration_options={
      chestB=-1,
      chestG=-1,
      chestR=-1,
      food_estimation=-1,
      food_order=0,
      food_style=0,
      lang="auto",
      show_food_units=-1,
      show_uses=-1 
    },
    enabled=true 
  },
  ["workshop-784481384"]={ configuration_options={ LOOK_Language="CH", RecipenNeed="EASY" }, enabled=true } 
}